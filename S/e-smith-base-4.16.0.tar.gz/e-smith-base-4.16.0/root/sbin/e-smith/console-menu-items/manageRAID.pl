package esmith::console::manageDiskRedundancy;

use esmith::console;
use Locale::gettext;

use Data::Dumper;

use constant DEBUG_MANAGE_RAID => 1;

sub new
{
    my $class = shift;
    my $self = {
		    name => "Manage disk redundancy",
		    order => 45,
		};
    bless $self, $class;
    return $self;
}

sub name
{
    return $_[0]->{name};
}

sub order
{
    return $_[0]->{order};
}

sub doit
{
    my $console = new esmith::console;

    use POSIX qw(strftime);
    my $today = strftime "%A %B %e, %Y %H:%M:%S", localtime;
    my $title = gettext("Disk redundancy status as of") . " " . $today,
    my $text = gettext("Current RAID status:") . "\n\n" . 
        join("", get_raid_status()) . "\n\n";

    my %devices = get_raid_details();

    warn $text if DEBUG_MANAGE_RAID;
    warn "devices: " . Dumper(%devices) . "\n" if DEBUG_MANAGE_RAID;

    unless (scalar %devices)
    {
        $text = gettext("There are no RAID devices configured");
        my ($rc, $choice) = $console->message_page(title => $title, text => $text);
        return;
    }

    unless (scalar keys %devices == 2)
    {
        $text .= gettext("There should be two RAID devices, not ") . 
                    scalar keys %devices;
        my ($rc, $choice) = $console->message_page(title => $title, text => $text);
        return;
    }

    for my $dev (keys %devices)
    {
        unless ($devices{$dev}{RaidLevel} eq "raid1")
        {
            $text .= gettext("One or more devices is not RAID1") . "\n\n" .
                gettext("Manual intervention may be required.") . "\n\n";
            my ($rc, $choice) = $console->message_page(title => $title, 
                            text => $text);
            return;
        }
    }

    my @unclean = ();
    my @recovering = ();
    my %used_disks = ();

    for my $dev (keys %devices)
    {
	$used_disks{$_}++ for (@{$devices{$dev}{UsedDisks}});

        if ($devices{$dev}{State} =~ /recovering/)
        {
            push @recovering, "$dev => " . $devices{$dev}{State};
            next;
        }

        next if ($devices{$dev}{State} eq "clean");

        push @unclean, "$dev => " . $devices{$dev}{State};
    }

    warn "used_disks: " . Dumper(%used_disks) . "\n" if DEBUG_MANAGE_RAID;

    warn "unclean: @unclean\n" if DEBUG_MANAGE_RAID;

    warn "recovering: @recovering\n" if DEBUG_MANAGE_RAID;

    if (scalar @recovering)
    {
        $text .= gettext("A RAID resynchronization is in progress.");
        my ($rc, $choice) = $console->message_page(title => $title, text => $text);
        return;
    }

    unless (scalar @unclean)
    {
        $text .= gettext("All RAID devices are in clean state");
        my ($rc, $choice) = $console->message_page(title => $title, text => $text);
        return;
    }

    unless (scalar @unclean == scalar keys %devices)
    {
        $text .= gettext("Only some of the RAID devices are unclean.") . 
		"\n\n" .
                gettext("Manual intervention may be required.") . "\n\n";

        my ($rc, $choice) = $console->message_page(title => $title, text => $text);
        return;
    }

    my %free_disks = map {$_ => 1} get_disks();

    delete $free_disks{$_} for keys %used_disks;

    warn "free_disks: " . Dumper(%free_disks) . "\n" if DEBUG_MANAGE_RAID;

    my $disk_status = gettext("Current disk status:") . "\n\n";
    $disk_status .= gettext("Installed disks") . ": " . 
                    join(" ", get_disks()) . "\n";
    $disk_status .= gettext("Used disks") . ": " . 
                    join(" ", keys %used_disks) . "\n";
    $disk_status .= gettext("Free disks") . ": " . 
                    join(" ", keys %free_disks) . "\n";

    if (scalar keys %used_disks == 1 and scalar keys %free_disks == 0)
    {
        $text .= gettext("Your system only has a single disk drive installed or is using hardware mirroring. If you would like to enable software mirroring, please shut down, install a second disk drive (of the same capacity) and then return to this screen.");

        my ($rc, $choice) = $console->message_page(title => $title, text => $text);
        return;
    }

    unless (scalar keys %used_disks == 1 and 
            scalar keys %free_disks == scalar keys %used_disks)
    {
        $text .= gettext("The free and used disk count must equal one.") .
                "\n\n" .
                gettext("Manual intervention may be required.") . "\n\n" .
                $disk_status;

        my ($rc, $choice) = $console->message_page(title => $title, text => $text);
        return;
    }

    my @cmd = ("/sbin/e-smith/add_mirror", "-f", join("", keys %used_disks), 
              join(" ", keys %free_disks));

    $text = $disk_status . 
        "\n\n" . 
        gettext("There is an unused disk drive in your system. Do you want to add it to the existing drive to make a RAID pair?") . 
        "\n\n";

    my ($rc, $choice) = $console->yesno_page(title => $title, text => $text);
    return unless ($rc == 0);

    unless (system(@cmd) == 0)
    {
        $text = gettext("The command @cmd failed.") .
                "\n\n" .
                gettext("This configuration is not yet fully supported in these screens.");

        my ($rc, $choice) = $console->message_page(title => $title, text => $text);
        return;
    }

}

sub get_raid_status
{
    die "Couldn't open /proc/mdstat:$!\n"
        unless (open(MDSTAT, "/proc/mdstat"));

    my @mdstat;

    while (<MDSTAT>)
    {
	push @mdstat, "$1\n" if (/(.*)/);
    }
    close MDSTAT;
    return @mdstat;
}

sub get_raid_details
{
    my @devices = ();

    die "Couldn't call mdadm: $!\n"
        unless open(MDADM, "/sbin/mdadm --detail --scan|");
   
    while (<MDADM>)
    {
        push @devices, $1 if ( m:ARRAY (/dev/md\d+): ) 
    }
    close MDADM;

    my %devices;

    for my $dev (@devices)
    {
        die "Couldn't call mdadm --detail $dev: $!\n" 
            unless open(MDADM, "/sbin/mdadm --detail $dev|");

        while ( <MDADM> )
        {
            if ( /\s*(.*)\s+:\s+(.*)\s*/ )
            {
                my ($key, $value) = ($1, $2);
                $key =~ s/\s//g;
                $devices{$dev}{$key} = $value;
            }

            if ( m:\s+(\d+)\s+(\d+)\s+(\d+).*/dev/(\w+): )
            {
                $devices{$dev}{$1} = $_;
		my $used_disk = $4;
		$used_disk =~ s/\d+//;
                push (@{$devices{$dev}{UsedDisks}}, $used_disk);
            }
        }
        close MDADM;
    }

    return %devices;
}

sub get_partitions
{
    die "Couldn't read /proc/partitions: $!\n" 
        unless open (PARTITIONS, "/proc/partitions");

    my %parts;

    while (<PARTITIONS>)
    {
        if ( /\s+(\d+)\s+(\d+)\s+(\d+)\s+(\w+)\s+/ )
        {
            my $name = $4;

            $parts{$name}{major} = $1;
            $parts{$name}{minor} = $2;
            $parts{$name}{blocks} = $3;
        }
    }
    close PARTITIONS;

    return %parts;
}

sub get_disks
{
    my %parts = get_partitions();

    my @disks;

    for (keys %parts)
    {
        push @disks, $_ unless (/[0-9]$/);
    }

    return @disks;
}

$screen = new esmith::console::manageDiskRedundancy;
# $screen->doit;
