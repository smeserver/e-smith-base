# /etc/profile.d/e-smith.sh - Custom additions for SME servers

export PATH=/sbin/e-smith:$PATH
