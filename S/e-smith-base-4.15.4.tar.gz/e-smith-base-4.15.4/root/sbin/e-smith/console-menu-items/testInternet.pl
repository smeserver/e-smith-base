package esmith::console::testInternetAccess;

sub new
{
    my $class = shift;
    my $self = {
		    name => "Test Internet access",
		    order => 30,
		};
    bless $self, $class;
    return $self;
}

sub name
{
    return $_[0]->{name};
}

sub order
{
    return $_[0]->{order};
}

sub doit
{
    esmith::console::testInternet();
}

return new esmith::console::testInternetAccess;
