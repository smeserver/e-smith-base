package esmith::console::reboot;

sub new
{
    my $class = shift;
    my $self = {
		    name => "Reboot, Reconfigure or shut down this server",
		    order => 40,
		};
    bless $self, $class;
    return $self;
}

sub name
{
    return $_[0]->{name};
}

sub order
{
    return $_[0]->{order};
}

sub doit
{
    esmith::console::rebootShutdown();
}

return new esmith::console::reboot;
