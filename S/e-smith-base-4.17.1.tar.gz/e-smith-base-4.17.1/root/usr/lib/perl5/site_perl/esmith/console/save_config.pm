package esmith::console::save_config;
use Locale::gettext;
use esmith::console;
use strict;
use warnings;

sub new
{
    my $class = shift;
    my $self = {};
    bless $self, $class;
    return $self;
}

sub doit
{
    my ($self, $console, $db) = @_;
    my $release = esmith::util::determineRelease();
    my $release_string = "Mitel Networks server ${release}";
    #------------------------------------------------------------
 SAVE_CONFIG:
    #------------------------------------------------------------
    # After saving config we don't need to run it again on the next reboot.
    $db->set_prop("bootstrap-console", "ForceSave", "no");
    $db->set_prop("bootstrap-console", "Run", "no");

    # XXX-FIXME
    # We call whiptail directly (rather than through the screen function)
    # as we don't want the --clear parameter passed by screen().
    # Appropriate magic can clean this up.

    system(
           "/usr/bin/whiptail",
           "--backtitle",
	   "$release_string Copyright 1999-2004 Mitel Networks Corporation",
           "--title", gettext("Activating configuration settings"),
           "--infobox", gettext("Please standby while your configuration settings are activated ..."),
           8, esmith::console::SCREEN_COLUMNS,
          );

    system("/sbin/e-smith/signal-event", 'bootstrap-console-save');
}
1;
