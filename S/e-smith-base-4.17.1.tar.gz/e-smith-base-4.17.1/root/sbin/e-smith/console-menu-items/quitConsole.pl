package esmith::console::quitConsole;
use esmith::console::quitConsole;
return new esmith::console::quitConsole;
