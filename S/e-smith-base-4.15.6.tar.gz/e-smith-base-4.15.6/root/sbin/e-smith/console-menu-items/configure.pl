package esmith::console::configure;

sub new
{
    my $class = shift;
    my $self = {
		    name => "Configure this server",
		    order => 20,
		};
    bless $self, $class;
    return $self;
}

sub name
{ 
    return $_[0]->{name};
}

sub order
{
    return $_[0]->{order};
}

sub doit
{
    goto CONFIGURE_INTRO;
}

return new esmith::console::configure;
