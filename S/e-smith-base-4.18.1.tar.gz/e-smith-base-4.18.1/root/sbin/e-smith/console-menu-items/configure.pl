package esmith::console::configure;
use esmith::console::configure;
return new esmith::console::configure;
