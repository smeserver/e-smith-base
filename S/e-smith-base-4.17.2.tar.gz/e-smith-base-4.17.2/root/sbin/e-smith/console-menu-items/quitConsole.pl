package esmith::console::quitConsole;

sub new
{
    my $class = shift;
    my $self = {
		    name => "Exit from the server console",
		    order => 100,
		};
    bless $self, $class;
    return $self;
}

sub name
{ 
    return $_[0]->{name};
}

sub order
{
    return -1 if (defined $ARGV [0]);

    return $_[0]->{order};
}

sub doit
{
    goto QUIT;
}

return new esmith::console::quitConsole;
